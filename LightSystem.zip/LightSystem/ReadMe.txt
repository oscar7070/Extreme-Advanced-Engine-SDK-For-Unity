v1.0
Open the documentation for help.
The documentation in the LightSystemFolder.
(You have a docs documentation and a pdf no difference between them).

known issues:

Fixed issues: